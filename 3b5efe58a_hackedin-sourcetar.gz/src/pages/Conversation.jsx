import { useState, useEffect, useRef } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Avatar from "@/components/Avatar";
import BackButton from "@/components/BackButton";
import { Send, Loader2, ArrowLeft } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

export default function Conversation() {
  const { userId: otherId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  const { data: otherProfile } = useQuery({
    queryKey: ["profile", otherId],
    queryFn: async () => (await base44.entities.Profile.filter({ user_id: otherId }))[0] || null,
  });

  const { data: messages = [], refetch, error: fetchError } = useQuery({
    queryKey: ["directMessages", otherId],
    queryFn: async () => {
      const res = await base44.functions.invoke("directChat", { action: "fetch", other_user_id: otherId });
      return res.data?.messages || [];
    },
    refetchInterval: 3000,
  });

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!text.trim() || sending) return;
    setSending(true);
    try {
      await base44.functions.invoke("directChat", { action: "send", other_user_id: otherId, message: text.trim() });
      setText("");
      await refetch();
    } catch (err) {
      toast({ title: "Failed to send", description: err.response?.data?.error || err.message, variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <BackButton label="Messages" />
      <div className="flex items-center gap-3 pb-3 border-b">
        <Link to={`/profile/${otherId}`}>
          <Avatar src={otherProfile?.profile_photo} name={otherProfile?.full_name || "User"} size="md" />
        </Link>
        <div className="min-w-0">
          <Link to={`/profile/${otherId}`} className="text-sm font-medium text-black hover:underline truncate block">{otherProfile?.full_name || "Unknown user"}</Link>
          <p className="text-xs text-black/70">{otherProfile?.college || "Direct message"}</p>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-3 py-4">
        {fetchError ? (
          <div className="h-full flex items-center justify-center text-sm text-destructive text-center px-4">
            Failed to load messages. {fetchError.response?.data?.error || fetchError.message}
          </div>
        ) : messages.length === 0 ? (
          <div className="h-full flex items-center justify-center text-sm text-black/70">No messages yet. Say hello 👋</div>
        ) : (
          messages.map((m) => {
            const mine = m.sender_id === user.id;
            return (
              <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[75%] rounded-2xl px-3.5 py-2 text-sm ${mine ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>
                  <p className="whitespace-pre-wrap break-words">{m.message}</p>
                </div>
              </div>
            );
          })
        )}
      </div>

      <form onSubmit={handleSend} className="flex items-center gap-2 pt-3 border-t">
        <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message..." disabled={sending} />
        <Button type="submit" size="icon" disabled={sending || !text.trim()}>
          {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </Button>
      </form>
    </div>
  );
}