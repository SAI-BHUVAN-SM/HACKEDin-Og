import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Avatar from "@/components/Avatar";
import StatusBadge from "@/components/StatusBadge";
import EmptyState from "@/components/EmptyState";
import BackButton from "@/components/BackButton";
import { Mail, Loader2, Check, X, Inbox } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

export default function Messages() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("requests");
  const [acting, setActing] = useState(null);

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["myMessageRequests"],
    queryFn: async () => {
      const [sent, received] = await Promise.all([
        base44.entities.MessageRequest.filter({ sender_id: user.id }),
        base44.entities.MessageRequest.filter({ receiver_id: user.id }),
      ]);
      return [...sent, ...received].sort((a, b) => (b.created_date || "").localeCompare(a.created_date || ""));
    },
  });

  const profileIds = Array.from(new Set(requests.map((r) => (r.sender_id === user.id ? r.receiver_id : r.sender_id))));
  const { data: profiles = [] } = useQuery({
    queryKey: ["messageProfiles", profileIds.join(",")],
    queryFn: async () => {
      if (profileIds.length === 0) return [];
      const all = await base44.entities.Profile.list();
      return all.filter((p) => profileIds.includes(p.user_id));
    },
    enabled: profileIds.length > 0,
  });
  const profileMap = Object.fromEntries(profiles.map((p) => [p.user_id, p]));

  const acceptedRequests = requests.filter((r) => r.status === "accepted");
  const conversationPartnerIds = Array.from(new Set(
    acceptedRequests.map((r) => (r.sender_id === user.id ? r.receiver_id : r.sender_id))
  ));

  const receivedPending = requests.filter((r) => r.receiver_id === user.id && r.status === "pending");
  const sentPending = requests.filter((r) => r.sender_id === user.id && r.status === "pending");
  const history = requests.filter((r) => r.status !== "pending");

  const handleRespond = async (req, status) => {
    setActing(req.id);
    try {
      await base44.entities.MessageRequest.update(req.id, { status });
      await base44.entities.Notification.create({
        user_id: req.sender_id,
        type: status === "accepted" ? "request_accepted" : "request_declined",
        message: `Your message request was ${status}.`,
        related_id: req.receiver_id,
        link: "/messages",
      });
      queryClient.invalidateQueries({ queryKey: ["myMessageRequests"] });
      toast({ title: `Request ${status}` });
    } catch (err) {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    } finally {
      setActing(null);
    }
  };

  const renderRow = (req) => {
    const otherId = req.sender_id === user.id ? req.receiver_id : req.sender_id;
    const p = profileMap[otherId];
    const isIncoming = req.receiver_id === user.id;
    return (
      <div key={req.id} className="flex items-start gap-3 p-3 rounded-lg border border-border">
        <Link to={`/profile/${otherId}`}>
          <Avatar src={p?.profile_photo} name={p?.full_name || "User"} size="md" />
        </Link>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <Link to={`/profile/${otherId}`} className="text-sm font-medium hover:underline truncate">{p?.full_name || "Unknown user"}</Link>
            <StatusBadge status={req.status} />
            <span className="text-xs text-muted-foreground">{isIncoming ? "received" : "sent"}</span>
          </div>
          {req.message && <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{req.message}</p>}
        </div>
        {isIncoming && req.status === "pending" && (
          <div className="flex items-center gap-1.5 shrink-0">
            <Button size="sm" disabled={acting === req.id} onClick={() => handleRespond(req, "accepted")}><Check className="w-3.5 h-3.5 mr-1" /> Accept</Button>
            <Button size="sm" variant="outline" disabled={acting === req.id} onClick={() => handleRespond(req, "declined")}><X className="w-3.5 h-3.5 mr-1" /> Decline</Button>
          </div>
        )}
        {req.status === "accepted" && (
          <Link to={`/messages/${otherId}`} className="shrink-0"><Button size="sm" variant="outline">Open chat</Button></Link>
        )}
      </div>
    );
  };

  return (
    <div>
      <BackButton label="Dashboard" />
      <div className="flex items-center gap-2 mb-6">
        <Mail className="w-6 h-6 text-black" />
        <h1 className="text-2xl font-heading tracking-wide uppercase text-black">Messages</h1>
      </div>

      <div className="flex items-center gap-2 mb-4">
        <Button variant={activeTab === "requests" ? "default" : "outline"} size="sm" onClick={() => setActiveTab("requests")}>
          Requests {receivedPending.length > 0 && <span className="ml-1.5 inline-flex items-center justify-center w-5 h-5 text-xs rounded-full bg-black/20">{receivedPending.length}</span>}
        </Button>
        <Button variant={activeTab === "conversations" ? "default" : "outline"} size="sm" onClick={() => setActiveTab("conversations")}>Conversations</Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : activeTab === "requests" ? (
        <div className="space-y-6">
          {receivedPending.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-base">Incoming requests ({receivedPending.length})</CardTitle></CardHeader>
              <CardContent className="space-y-2">{receivedPending.map(renderRow)}</CardContent>
            </Card>
          )}
          {sentPending.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-base">Sent requests ({sentPending.length})</CardTitle></CardHeader>
              <CardContent className="space-y-2">{sentPending.map(renderRow)}</CardContent>
            </Card>
          )}
          {history.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-base">History</CardTitle></CardHeader>
              <CardContent className="space-y-2">{history.map(renderRow)}</CardContent>
            </Card>
          )}
          {requests.length === 0 && (
            <EmptyState icon={Inbox} title="No message requests yet" description="When someone wants to chat privately, their request appears here." />
          )}
        </div>
      ) : (
        <Card>
          <CardHeader><CardTitle className="text-base">Active conversations</CardTitle></CardHeader>
          <CardContent>
            {conversationPartnerIds.length === 0 ? (
              <EmptyState icon={Mail} title="No conversations yet" description="Accept a message request to start chatting privately." />
            ) : (
              <div className="space-y-2">
                {conversationPartnerIds.map((otherId) => {
                  const p = profileMap[otherId];
                  return (
                    <Link key={otherId} to={`/messages/${otherId}`} className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-accent">
                      <Avatar src={p?.profile_photo} name={p?.full_name || "User"} size="md" />
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{p?.full_name || "Unknown user"}</p>
                        <p className="text-xs text-muted-foreground truncate">{p?.college || "Open conversation"}</p>
                      </div>
                    </Link>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}