import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { useProfile, useInvalidateProfile } from "@/lib/useProfile";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import Avatar from "@/components/Avatar";
import { Mail, Pencil, LogOut, User, RefreshCw, Loader2, Trash2, AlertTriangle } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Settings() {
  const { user, logout } = useAuth();
  const { data: profile } = useProfile();
  const invalidateProfile = useInvalidateProfile();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [changingRole, setChangingRole] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState("");
  const [deleting, setDeleting] = useState(false);

  const handleDeleteAccount = async () => {
    setDeleting(true);
    try {
      await base44.functions.invoke("deleteAccount", {});
      queryClient.clear();
      logout(false);
      navigate("/login");
      toast({ title: "Account deleted", description: "Your account and data have been removed." });
    } catch (err) {
      toast({ title: "Failed to delete account", description: err.message, variant: "destructive" });
    } finally {
      setDeleting(false);
      setDeleteOpen(false);
      setDeleteConfirm("");
    }
  };

  const handleLogout = () => {
    queryClient.clear();
    logout(false);
    navigate("/login");
  };

  const handleChangeRole = async () => {
    if (!profile) return;
    const newRole = profile.role === "team_leader" ? "participant" : "team_leader";
    setChangingRole(true);
    try {
      await base44.entities.Profile.update(profile.id, { role: newRole });
      await invalidateProfile();
      queryClient.invalidateQueries();
      toast({ title: "Role updated", description: `You are now a ${newRole === "team_leader" ? "Team Leader" : "Participant"}.` });
    } catch (err) {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    } finally {
      setChangingRole(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <PageHeader title="Settings" description="Manage your account and preferences." />

      <Card className="mb-6">
        <CardContent className="p-5 flex items-center gap-4">
          <Avatar src={profile?.profile_photo} name={profile?.full_name} size="lg" />
          <div className="flex-1 min-w-0">
            <p className="font-semibold">{profile?.full_name}</p>
            <p className="text-sm text-muted-foreground truncate">{user?.email}</p>
            <div className="flex items-center gap-2 mt-1.5">
              {profile && <StatusBadge status={profile.role} />}
              {profile && <StatusBadge status={profile.availability} />}
            </div>
          </div>
          <Link to="/profile"><Button variant="outline" size="sm"><Pencil className="w-3.5 h-3.5 mr-1.5" /> Edit profile</Button></Link>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader><CardTitle className="text-base">Account</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between py-2">
            <div className="flex items-center gap-2.5 text-sm"><Mail className="w-4 h-4 text-muted-foreground" /> Email</div>
            <span className="text-sm text-muted-foreground">{user?.email}</span>
          </div>
          <div className="flex items-center justify-between py-2 border-t border-border">
            <div className="flex items-center gap-2.5 text-sm"><User className="w-4 h-4 text-muted-foreground" /> Role</div>
            <div className="flex items-center gap-2">
              <StatusBadge status={profile?.role || "participant"} />
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm" disabled={changingRole || !profile}>
                    <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Change role
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Switch to {profile?.role === "team_leader" ? "Participant" : "Team Leader"}?</AlertDialogTitle>
                    <AlertDialogDescription>
                      {profile?.role === "team_leader"
                        ? "You'll be able to browse and join teams as a participant. Your existing teams and memberships are kept."
                        : "You'll be able to create teams and invite participants. Your existing memberships are kept."}
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleChangeRole} disabled={changingRole}>
                      {changingRole ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                      Confirm
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Session</CardTitle></CardHeader>
        <CardContent>
          <Button variant="outline" onClick={handleLogout} className="text-rose-600 hover:text-rose-700 hover:bg-rose-50">
            <LogOut className="w-4 h-4 mr-2" /> Log out
          </Button>
        </CardContent>
      </Card>

      <Card className="border-rose-200">
        <CardHeader><CardTitle className="text-base text-rose-600 flex items-center gap-2"><AlertTriangle className="w-4 h-4" /> Danger zone</CardTitle></CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">Deleting your account is permanent and cannot be undone. It removes your profile, memberships, teams you own, requests, and messages.</p>
          <AlertDialog open={deleteOpen} onOpenChange={(o) => { setDeleteOpen(o); if (!o) setDeleteConfirm(""); }}>
            <AlertDialogTrigger asChild>
              <Button variant="destructive"><Trash2 className="w-4 h-4 mr-2" /> Delete account</Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This permanently deletes your account and all associated data. Teams you own will be deleted and their members notified. To confirm, type <span className="font-semibold text-foreground">DELETE</span> below.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <input
                value={deleteConfirm}
                onChange={(e) => setDeleteConfirm(e.target.value)}
                placeholder="Type DELETE to confirm"
                className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
              />
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleDeleteAccount}
                  disabled={deleting || deleteConfirm !== "DELETE"}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  {deleting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                  Delete forever
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </div>
  );
}