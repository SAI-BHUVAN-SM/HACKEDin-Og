import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { useProfile } from "@/lib/useProfile";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageSquare, Loader2 } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { useQueryClient } from "@tanstack/react-query";

export default function MessageRequestButton({ targetUser, targetName, variant = "outline", size = "sm", label = "Message", fullWidth = false }) {
  const { user } = useAuth();
  const { data: myProfile } = useProfile();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    setSending(true);
    try {
      // Prevent duplicate requests: check for existing pending or accepted request
      const [sent, received] = await Promise.all([
        base44.entities.MessageRequest.filter({ sender_id: user.id, receiver_id: targetUser }),
        base44.entities.MessageRequest.filter({ sender_id: targetUser, receiver_id: user.id }),
      ]);
      const existing = [...sent, ...received];
      const hasActive = existing.some((r) => r.status === "pending" || r.status === "accepted");
      if (hasActive) {
        toast({ title: "Already requested", description: "You already have a pending or accepted request with this user." });
        setOpen(false);
        setMessage("");
        return;
      }
      await base44.entities.MessageRequest.create({
        sender_id: user.id,
        receiver_id: targetUser,
        status: "pending",
        message: message.trim(),
      });
      await base44.entities.Notification.create({
        user_id: targetUser,
        type: "chat_message",
        message: `${myProfile?.full_name || "Someone"} sent you a message request.`,
        related_id: user.id,
        link: "/messages",
      });
      queryClient.invalidateQueries({ queryKey: ["myMessageRequests"] });
      toast({ title: "Message request sent", description: `You'll be able to chat once ${targetName || "the user"} accepts.` });
      setOpen(false);
      setMessage("");
    } catch (err) {
      toast({ title: "Failed to send", description: err.message, variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <Button variant={variant} size={size} onClick={() => setOpen(true)} className={fullWidth ? "w-full" : ""}>
        <MessageSquare className="w-3.5 h-3.5 mr-1.5" /> {label}
      </Button>
      <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setMessage(""); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Message {targetName || "this user"}</DialogTitle>
            <DialogDescription>Send a message request. You can chat privately once they accept.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Introduce yourself and what you'd like to discuss..." rows={3} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={handleSend} disabled={sending}>
              {sending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              Send request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}