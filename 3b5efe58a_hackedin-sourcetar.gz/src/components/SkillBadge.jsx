import { cn } from "@/lib/utils";

export default function SkillBadge({ children, className, variant = "default" }) {
  const variants = {
    default: "bg-[#B7EF34] text-black",
    tech: "bg-black text-[#B7EF34] border-2 border-[#B7EF34]",
    nontech: "bg-[#C8FF45] text-black",
    role: "bg-black text-[#B7EF34] border-2 border-[#B7EF34]",
  };
  return (
    <span className={cn("inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wide border-2 border-black", variants[variant], className)}>
      {children}
    </span>
  );
}