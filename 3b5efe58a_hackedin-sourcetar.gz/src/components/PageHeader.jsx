export default function PageHeader({ title, description, children }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
      <div>
        <h1 className="font-heading text-4xl sm:text-5xl tracking-wide uppercase text-heading text-extrude leading-none">{title}</h1>
        {description && <p className="text-sm text-foreground/70 font-medium mt-2">{description}</p>}
      </div>
      {children && <div className="flex items-center gap-2">{children}</div>}
    </div>
  );
}