import { useState, useEffect } from "react";
import { Link, Outlet, useLocation, useNavigate, Navigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { useProfile } from "@/lib/useProfile";
import Avatar from "@/components/Avatar";
import Logo from "@/components/Logo";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard, Users, UserSearch, FolderKanban, Inbox, Bell, User, Settings,
  LogOut, Menu, X, ChevronDown, Mail
} from "lucide-react";

export default function AppLayout() {
  const { user, logout } = useAuth();
  const { data: profile, isLoading: profileLoading } = useProfile();
  const queryClient = useQueryClient();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const isLeader = profile?.role === "team_leader";

  const navItems = [
    { label: "Dashboard", path: "/", icon: LayoutDashboard },
    { label: "Discover Teams", path: "/teams", icon: FolderKanban },
    ...(isLeader ? [{ label: "Discover Participants", path: "/participants", icon: UserSearch }] : []),
    { label: "My Teams", path: "/my-teams", icon: Users },
    { label: "Requests", path: "/requests", icon: Inbox },
    { label: "Messages", path: "/messages", icon: Mail },
    { label: "Notifications", path: "/notifications", icon: Bell },
  ];

  const { data: unread } = useQuery({
    queryKey: ["unreadNotifications", user?.id],
    queryFn: async () => {
      const notifs = await base44.entities.Notification.filter({ user_id: user.id, read_status: false });
      return notifs.length;
    },
    enabled: !!user?.id,
    refetchInterval: 15000,
  });

  useEffect(() => {
    setMobileOpen(false);
    setUserMenuOpen(false);
  }, [location.pathname]);

  if (!profileLoading && profile === null) {
    return <Navigate to="/onboarding" replace />;
  }

  const handleLogout = () => {
    queryClient.clear();
    logout(false);
    navigate("/login");
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 px-6 py-5 border-b-2 border-black">
        <Logo className="w-9 h-9 rounded-xl border-2 border-black" />
        <span className="text-xl font-heading tracking-widest text-white">HACKEDin</span>
      </div>
      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const active = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold transition-all",
                active ? "bg-[#B7EF34] text-black border-2 border-black" : "text-white/70 hover:bg-white/10 hover:text-white border-2 border-transparent"
              )}
            >
              <item.icon className="w-4.5 h-4.5" style={{ width: 18, height: 18 }} />
              <span>{item.label}</span>
              {item.path === "/notifications" && unread > 0 && (
                <span className="ml-auto bg-rose-500 text-white text-xs px-1.5 py-0.5 rounded-full min-w-[20px] text-center font-bold">{unread}</span>
              )}
            </Link>
          );
        })}
      </nav>
      <div className="px-3 py-4 border-t-2 border-black space-y-1">
        <Link
          to="/profile"
          className={cn(
            "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold transition-all",
            location.pathname === "/profile" ? "bg-[#B7EF34] text-black border-2 border-black" : "text-white/70 hover:bg-white/10 hover:text-white border-2 border-transparent"
          )}
        >
          <User style={{ width: 18, height: 18 }} />
          <span>My Profile</span>
        </Link>
        <Link
          to="/settings"
          className={cn(
            "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold transition-all",
            location.pathname === "/settings" ? "bg-[#B7EF34] text-black border-2 border-black" : "text-white/70 hover:bg-white/10 hover:text-white border-2 border-transparent"
          )}
        >
          <Settings style={{ width: 18, height: 18 }} />
          <span>Settings</span>
        </Link>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold text-white/70 hover:bg-white/10 hover:text-white transition-all border-2 border-transparent"
        >
          <LogOut style={{ width: 18, height: 18 }} />
          <span>Log out</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex fixed inset-y-0 left-0 w-64 border-r-2 border-black bg-[#171717] flex-col z-30">
        <SidebarContent />
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-64 bg-[#171717] flex flex-col">
            <button className="absolute top-4 right-4 p-1 text-white" onClick={() => setMobileOpen(false)}>
              <X className="w-5 h-5" />
            </button>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Topbar */}
        <header className="sticky top-0 z-20 bg-white dark:bg-accent border-b-2 border-black">
          <div className="relative flex items-center justify-center h-16 px-4 sm:px-6">
            <button className="lg:hidden absolute left-2 p-2 text-black" onClick={() => setMobileOpen(true)}>
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2.5">
              <Logo className="w-14 h-14 rounded-xl" />
              <span className="text-xl font-heading tracking-widest text-black">HACKEDin</span>
            </div>
            <div className="absolute right-2 flex items-center gap-2">
              <Link to="/notifications" className="relative p-2 rounded-lg hover:bg-black/10 transition-colors">
                <Bell className="w-5 h-5 text-black/80" />
                {unread > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-black text-white text-[10px] rounded-full flex items-center justify-center font-bold">{unread > 9 ? "9" : unread}</span>
                )}
              </Link>
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 p-1 pr-2 rounded-lg hover:bg-black/10 transition-colors"
                >
                  <Avatar src={profile?.profile_photo} name={profile?.full_name || user?.email} size="sm" />
                  <span className="hidden sm:block text-sm font-bold max-w-[120px] truncate text-black">{profile?.full_name || "User"}</span>
                  <ChevronDown className="w-4 h-4 text-black/60" />
                </button>
                {userMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-card border-2 border-border rounded-xl shadow-lg py-1.5 z-50">
                    <Link to="/profile" className="block px-4 py-2 text-sm font-medium text-card-foreground hover:bg-accent hover:text-accent-foreground">My Profile</Link>
                    <Link to="/settings" className="block px-4 py-2 text-sm font-medium text-card-foreground hover:bg-accent hover:text-accent-foreground">Settings</Link>
                    <button onClick={handleLogout} className="w-full text-left px-4 py-2 text-sm font-medium text-destructive hover:bg-accent hover:text-accent-foreground">Log out</button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>
        <main className="px-4 sm:px-6 lg:px-8 py-6 max-w-7xl mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}