import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva } from "class-variance-authority";

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-2xl text-sm font-bold tracking-tight transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50 active:translate-y-px [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "bg-primary text-primary-foreground border-2 border-primary shadow-[0_3px_0_0_#000000] hover:shadow-[0_4px_0_0_#000000] hover:-translate-y-0.5 active:shadow-[0_1px_0_0_#000000] active:translate-y-0.5",
        destructive:
          "bg-destructive text-destructive-foreground border-2 border-destructive shadow-[0_3px_0_0_#000000] hover:shadow-[0_4px_0_0_#000000] hover:-translate-y-0.5 active:shadow-[0_1px_0_0_#000000] active:translate-y-0.5",
        outline:
          "border-2 border-border bg-card text-card-foreground hover:bg-accent hover:text-accent-foreground shadow-[0_3px_0_0_#000000] hover:shadow-[0_4px_0_0_#000000] hover:-translate-y-0.5 active:shadow-[0_1px_0_0_#000000] active:translate-y-0.5",
        secondary:
          "bg-secondary text-secondary-foreground border-2 border-border hover:bg-secondary/80",
        ghost: "text-current hover:bg-foreground/10",
        link: "text-link underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-5 py-2",
        sm: "h-9 rounded-xl px-3 text-xs",
        lg: "h-12 rounded-2xl px-8 text-base",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

const Button = React.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button"
  return (
    (<Comp
      className={cn(buttonVariants({ variant, size, className }))}
      ref={ref}
      {...props} />)
  );
})
Button.displayName = "Button"

export { Button, buttonVariants }