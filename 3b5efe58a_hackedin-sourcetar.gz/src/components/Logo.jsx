import { cn } from "@/lib/utils";

export default function Logo({ className }) {
  return (
    <div
      className={cn(
        "flex items-center justify-center rounded-xl bg-accent text-black font-heading shrink-0",
        className
      )}
    >
      H
    </div>
  );
}