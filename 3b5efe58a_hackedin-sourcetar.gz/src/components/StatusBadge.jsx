import { cn } from "@/lib/utils";

const variants = {
  open: "bg-accent text-accent-foreground",
  locked: "bg-secondary text-secondary-foreground",
  available: "bg-accent text-accent-foreground",
  busy: "bg-amber-400 text-black",
  unavailable: "bg-rose-500 text-white",
  pending: "bg-secondary text-secondary-foreground",
  accepted: "bg-accent text-accent-foreground",
  declined: "bg-rose-500 text-white",
  cancelled: "bg-secondary text-muted-foreground",
  participant: "bg-accent text-accent-foreground",
  team_leader: "bg-primary text-primary-foreground",
};

export default function StatusBadge({ status, className }) {
  const variant = variants[status] || "bg-secondary text-secondary-foreground";
  return (
    <span className={cn("inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide border-2 border-border", variant, className)}>
      {status?.replace("_", " ")}
    </span>
  );
}