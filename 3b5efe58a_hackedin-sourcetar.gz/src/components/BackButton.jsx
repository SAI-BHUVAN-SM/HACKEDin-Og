import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

export default function BackButton({ to, fallback = "/", label = "Back", className = "" }) {
  const navigate = useNavigate();
  const handleBack = () => {
    if (to) navigate(to);
    else if (window.history.length > 1) navigate(-1);
    else navigate(fallback);
  };
  return (
    <button
      type="button"
      onClick={handleBack}
      className={cn(
        "inline-flex items-center gap-1.5 h-9 px-3.5 mb-4 rounded-xl text-sm font-semibold",
        "border-2 border-border bg-card text-foreground/80 hover:bg-accent hover:text-accent-foreground",
        "active:translate-y-px transition-all duration-150",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        className
      )}
    >
      <ArrowLeft className="w-4 h-4" /> {label}
    </button>
  );
}