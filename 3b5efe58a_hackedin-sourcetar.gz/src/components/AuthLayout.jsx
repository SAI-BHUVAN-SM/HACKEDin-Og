import React from "react";
import Logo from "@/components/Logo";

export default function AuthLayout({ title, subtitle, footer, children }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <Logo className="w-14 h-14 rounded-2xl border-2 border-black mx-auto mb-4" />
          <h1 className="text-3xl font-bold tracking-tight text-black">{title}</h1>
          {subtitle && <p className="text-black/70 mt-2">{subtitle}</p>}
        </div>
        <div className="bg-card rounded-2xl shadow-[0_5px_0_0_#000000] border-2 border-black p-8">
          {children}
        </div>
        {footer && (
          <p className="text-center text-sm text-black/70 mt-6">{footer}</p>
        )}
      </div>
    </div>
  );
}