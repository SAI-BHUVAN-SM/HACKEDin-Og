import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Permanently removes the calling user's personal data and handles teams they
// own safely (cascades members, requests, messages, and notifies members).
// The auth account itself is removed by the platform after this cleanup when
// possible; this function guarantees no orphaned personal data remains.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const userId = user.id;

    // 1. Teams owned by the user — cascade delete each fully.
    const ledTeams = await base44.asServiceRole.entities.Team.filter({ leader_id: userId });
    for (const team of (ledTeams || [])) {
      const members = await base44.asServiceRole.entities.TeamMember.filter({ team_id: team.id });
      const requests = await base44.asServiceRole.entities.Request.filter({ team_id: team.id });
      const messages = await base44.asServiceRole.entities.Message.filter({ team_id: team.id });

      for (const m of (members || [])) {
        if (m.user_id !== userId) {
          await base44.asServiceRole.entities.Notification.create({
            user_id: m.user_id,
            type: 'roster_change',
            message: `${team.team_name} has been deleted because the team leader deleted their account.`,
            related_id: team.id,
          }).catch(() => {});
        }
        await base44.asServiceRole.entities.TeamMember.delete(m.id).catch(() => {});
      }
      for (const r of (requests || [])) await base44.asServiceRole.entities.Request.delete(r.id).catch(() => {});
      for (const msg of (messages || [])) await base44.asServiceRole.entities.Message.delete(msg.id).catch(() => {});
      await base44.asServiceRole.entities.Team.delete(team.id).catch(() => {});
    }

    // 2. Memberships where the user is a member (not leader).
    const memberships = await base44.asServiceRole.entities.TeamMember.filter({ user_id: userId });
    for (const m of (memberships || [])) {
      await base44.asServiceRole.entities.TeamMember.delete(m.id).catch(() => {});
    }

    // 3. Requests sent or received.
    const sentRequests = await base44.asServiceRole.entities.Request.filter({ sender_id: userId });
    for (const r of (sentRequests || [])) await base44.asServiceRole.entities.Request.delete(r.id).catch(() => {});
    const receivedRequests = await base44.asServiceRole.entities.Request.filter({ receiver_id: userId });
    for (const r of (receivedRequests || [])) await base44.asServiceRole.entities.Request.delete(r.id).catch(() => {});

    // 4. Notifications addressed to the user.
    const notifications = await base44.asServiceRole.entities.Notification.filter({ user_id: userId });
    for (const n of (notifications || [])) await base44.asServiceRole.entities.Notification.delete(n.id).catch(() => {});

    // 5. Team chat messages sent by the user.
    const teamMessages = await base44.asServiceRole.entities.Message.filter({ sender_id: userId });
    for (const msg of (teamMessages || [])) await base44.asServiceRole.entities.Message.delete(msg.id).catch(() => {});

    // 6. Direct messages involving the user (either side) and message requests.
    const dmA = await base44.asServiceRole.entities.DirectMessage.filter({ user_a_id: userId });
    for (const m of (dmA || [])) await base44.asServiceRole.entities.DirectMessage.delete(m.id).catch(() => {});
    const dmB = await base44.asServiceRole.entities.DirectMessage.filter({ user_b_id: userId });
    for (const m of (dmB || [])) await base44.asServiceRole.entities.DirectMessage.delete(m.id).catch(() => {});
    const mrSent = await base44.asServiceRole.entities.MessageRequest.filter({ sender_id: userId });
    for (const m of (mrSent || [])) await base44.asServiceRole.entities.MessageRequest.delete(m.id).catch(() => {});
    const mrReceived = await base44.asServiceRole.entities.MessageRequest.filter({ receiver_id: userId });
    for (const m of (mrReceived || [])) await base44.asServiceRole.entities.MessageRequest.delete(m.id).catch(() => {});

    // 7. Profile.
    const profiles = await base44.asServiceRole.entities.Profile.filter({ user_id: userId });
    for (const p of (profiles || [])) await base44.asServiceRole.entities.Profile.delete(p.id).catch(() => {});

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message || 'Server error' }, { status: 500 });
  }
}