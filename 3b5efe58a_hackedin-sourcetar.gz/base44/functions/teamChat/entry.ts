import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { action, team_id, message } = body;

    if (!team_id) return Response.json({ error: 'Team id required' }, { status: 400 });

    // Verify the caller is a member of this team (TeamMember record exists)
    const memberships = await base44.entities.TeamMember.filter({ team_id, user_id: user.id });
    if (!memberships || memberships.length === 0) {
      return Response.json({ error: 'You are not a member of this team' }, { status: 403 });
    }

    if (action === 'fetch') {
      const messages = await base44.asServiceRole.entities.Message.filter({ team_id }, 'created_date', 200);
      return Response.json({ messages: messages || [] });
    }

    if (action === 'send') {
      if (!message || !message.trim()) {
        return Response.json({ error: 'Message cannot be empty' }, { status: 400 });
      }
      const created = await base44.asServiceRole.entities.Message.create({
        team_id,
        sender_id: user.id,
        sender_name: user.full_name || user.email,
        message: message.trim().slice(0, 2000)
      });
      return Response.json({ message: created });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message || 'Server error' }, { status: 500 });
  }
}