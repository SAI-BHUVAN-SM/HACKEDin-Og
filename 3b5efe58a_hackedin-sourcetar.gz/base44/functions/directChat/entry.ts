import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Private 1:1 conversation between two users. Access is gated by an accepted
// MessageRequest between the caller and the other user. DirectMessage records
// are admin-only via RLS, so all reads/writes go through this function.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let body;
    try {
      body = await req.json();
    } catch (e) {
      return Response.json({ error: 'Invalid request body' }, { status: 400 });
    }

    const { action, other_user_id, message } = body || {};
    if (!other_user_id) return Response.json({ error: 'other_user_id is required' }, { status: 400 });
    if (other_user_id === user.id) return Response.json({ error: 'Cannot message yourself' }, { status: 400 });

    // Verify an accepted MessageRequest exists between the two users (either direction).
    const [sentReq, recvReq] = await Promise.all([
      base44.asServiceRole.entities.MessageRequest.filter({ sender_id: user.id, receiver_id: other_user_id }),
      base44.asServiceRole.entities.MessageRequest.filter({ sender_id: other_user_id, receiver_id: user.id }),
    ]);
    const allReq = [...(sentReq || []), ...(recvReq || [])];
    const accepted = allReq.find((r) => r.status === 'accepted');
    if (!accepted) {
      return Response.json({ error: 'No accepted message request with this user' }, { status: 403 });
    }

    // Sorted pair so the conversation is stored deterministically.
    const [user_a_id, user_b_id] = [user.id, other_user_id].sort();

    if (action === 'fetch') {
      const messages = await base44.asServiceRole.entities.DirectMessage.filter({ user_a_id, user_b_id }, 'created_date', 200);
      return Response.json({ messages: messages || [] });
    }

    if (action === 'send') {
      if (!message || !message.trim()) {
        return Response.json({ error: 'Message cannot be empty' }, { status: 400 });
      }
      const created = await base44.asServiceRole.entities.DirectMessage.create({
        user_a_id,
        user_b_id,
        sender_id: user.id,
        sender_name: user.full_name || user.email,
        message: message.trim().slice(0, 2000),
      });
      return Response.json({ message: created });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message || 'Server error' }, { status: 500 });
  }
}