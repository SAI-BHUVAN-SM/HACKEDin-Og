import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Securely resolves (accept/decline) a team Request on behalf of the authenticated
// receiver. Runs as service role so it can create TeamMember records whose
// leader_id is NOT the acting user (which the TeamMember RLS blocks client-side),
// but only after verifying the caller is the request's receiver and the request
// is still pending. This keeps TeamMember non-public-writable while allowing
// invitees to accept invitations.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { request_id, action, assigned_role } = body;
    if (!request_id || !action) {
      return Response.json({ error: 'request_id and action are required' }, { status: 400 });
    }
    if (action !== 'accept' && action !== 'decline') {
      return Response.json({ error: 'action must be accept or decline' }, { status: 400 });
    }

    // Fetch the request as service role (we enforce authorization ourselves).
    let request;
    try {
      request = await base44.asServiceRole.entities.Request.get(request_id);
    } catch (e) {
      return Response.json({ error: 'Request not found' }, { status: 404 });
    }
    if (!request) return Response.json({ error: 'Request not found' }, { status: 404 });

    // Only the intended recipient may accept/decline.
    if (request.receiver_id !== user.id) {
      return Response.json({ error: 'Only the request recipient can resolve this request' }, { status: 403 });
    }
    if (request.status !== 'pending') {
      return Response.json({ error: `Request is already ${request.status}` }, { status: 409 });
    }

    // Fetch the team.
    let team;
    try {
      team = await base44.asServiceRole.entities.Team.get(request.team_id);
    } catch (e) {
      return Response.json({ error: 'Team not found' }, { status: 404 });
    }

    // For invitations the joining user is the receiver (current user).
    // For join requests the joining user is the sender.
    const joiningUserId = request.request_type === 'invitation' ? user.id : request.sender_id;
    const otherPartyId = request.request_type === 'invitation' ? team.leader_id : request.sender_id;

    if (action === 'accept') {
      // Locked teams block join requests, but a leader's invitation may still be
      // accepted so the leader can fill a vacancy on a locked roster.
      if (team.status === 'locked' && request.request_type === 'join_request') {
        return Response.json({ error: 'Team is locked' }, { status: 409 });
      }
      // Count current members.
      const existing = await base44.asServiceRole.entities.TeamMember.filter({ team_id: team.id });
      const count = existing ? existing.length : 0;
      if (count >= team.max_members) {
        return Response.json({ error: 'Team is full' }, { status: 409 });
      }
      // Validate the assigned role (if any) against the team's open roles.
      let roleToAssign = assigned_role || null;
      if (roleToAssign) {
        const roleTaken = existing.some((m) => m.assigned_role === roleToAssign);
        if (roleTaken) {
          return Response.json({ error: 'That role is already taken by another member' }, { status: 409 });
        }
        if (team.required_roles && team.required_roles.length > 0 && !team.required_roles.includes(roleToAssign)) {
          return Response.json({ error: 'That role is not listed by the team' }, { status: 400 });
        }
      }
      // Prevent duplicate membership.
      const alreadyMember = existing.some((m) => m.user_id === joiningUserId);
      if (!alreadyMember) {
        await base44.asServiceRole.entities.TeamMember.create({
          team_id: team.id,
          user_id: joiningUserId,
          leader_id: team.leader_id,
          joined_at: new Date().toISOString(),
          status: 'member',
          assigned_role: roleToAssign,
        });
      }
      await base44.asServiceRole.entities.Request.update(request.id, { status: 'accepted' });

      const joiningName = request.request_type === 'invitation'
        ? (user.full_name || user.email)
        : (user.full_name || user.email); // receiver is accepting; for join_request the receiver is the leader
      const notifyMsg = request.request_type === 'invitation'
        ? `${joiningName} accepted your invitation to join ${team.team_name}.`
        : `Your request to join ${team.team_name} was accepted!`;
      if (otherPartyId) {
        await base44.asServiceRole.entities.Notification.create({
          user_id: otherPartyId,
          type: 'request_accepted',
          message: notifyMsg,
          related_id: team.id,
          link: `/team/${team.id}`,
        });
      }
      return Response.json({ ok: true, status: 'accepted', team_id: team.id, team_name: team.team_name });
    }

    // action === 'decline'
    await base44.asServiceRole.entities.Request.update(request.id, { status: 'declined' });
    const declineMsg = request.request_type === 'invitation'
      ? `${user.full_name || user.email} declined your invitation to join ${team.team_name}.`
      : `Your request to join ${team.team_name} was declined.`;
    if (otherPartyId) {
      await base44.asServiceRole.entities.Notification.create({
        user_id: otherPartyId,
        type: 'request_declined',
        message: declineMsg,
        related_id: team.id,
      });
    }
    return Response.json({ ok: true, status: 'declined' });
  } catch (error) {
    return Response.json({ error: error.message || 'Server error' }, { status: 500 });
  }
}