import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Deletes a team and cascades all related records (members, requests,
// messages, notifications to members). Only the team leader may call this.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { team_id } = body;
    if (!team_id) return Response.json({ error: 'team_id is required' }, { status: 400 });

    let team;
    try {
      team = await base44.asServiceRole.entities.Team.get(team_id);
    } catch (e) {
      return Response.json({ error: 'Team not found' }, { status: 404 });
    }
    if (!team) return Response.json({ error: 'Team not found' }, { status: 404 });

    if (team.leader_id !== user.id) {
      return Response.json({ error: 'Only the team leader can delete this team' }, { status: 403 });
    }

    const members = await base44.asServiceRole.entities.TeamMember.filter({ team_id });
    const requests = await base44.asServiceRole.entities.Request.filter({ team_id });
    const messages = await base44.asServiceRole.entities.Message.filter({ team_id });

    // Notify non-leader members about the deletion.
    for (const m of (members || [])) {
      if (m.user_id !== user.id) {
        await base44.asServiceRole.entities.Notification.create({
          user_id: m.user_id,
          type: 'roster_change',
          message: `${team.team_name} has been deleted by the team leader.`,
          related_id: team.id,
        }).catch(() => {});
      }
    }

    for (const r of (requests || [])) {
      await base44.asServiceRole.entities.Request.delete(r.id).catch(() => {});
    }
    for (const msg of (messages || [])) {
      await base44.asServiceRole.entities.Message.delete(msg.id).catch(() => {});
    }
    for (const m of (members || [])) {
      await base44.asServiceRole.entities.TeamMember.delete(m.id).catch(() => {});
    }
    await base44.asServiceRole.entities.Team.delete(team.id).catch(() => {});

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message || 'Server error' }, { status: 500 });
  }
}