import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Allows a non-leader member to leave an unlocked team. Enforces the lock
// restriction server-side (TeamMember delete RLS is leader-only, so members
// cannot bypass this by calling the entity API directly).
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { team_id } = body;
    if (!team_id) return Response.json({ error: 'team_id is required' }, { status: 400 });

    let team;
    try {
      team = await base44.asServiceRole.entities.Team.get(team_id);
    } catch (e) {
      return Response.json({ error: 'Team not found' }, { status: 404 });
    }
    if (!team) return Response.json({ error: 'Team not found' }, { status: 404 });

    if (team.status === 'locked') {
      return Response.json({ error: 'You cannot leave a locked team' }, { status: 409 });
    }
    if (team.leader_id === user.id) {
      return Response.json({ error: 'Team leaders cannot leave their own team. Delete the team instead.' }, { status: 400 });
    }

    const memberships = await base44.asServiceRole.entities.TeamMember.filter({ team_id, user_id: user.id });
    if (!memberships || memberships.length === 0) {
      return Response.json({ error: 'You are not a member of this team' }, { status: 404 });
    }
    for (const m of memberships) {
      await base44.asServiceRole.entities.TeamMember.delete(m.id).catch(() => {});
    }

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message || 'Server error' }, { status: 500 });
  }
}